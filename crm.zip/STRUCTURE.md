# 📁 Структура проекта BarberCRM v4.0

## Корневая директория

```
barber-crm-v4.0/
├── 📂 backend/                    # Серверная часть (FastAPI)
│   ├── main.py                   # Основной код API (750 строк)
│   ├── requirements.txt          # Python зависимости
│   └── Dockerfile               # Docker образ для бэкенда
│
├── 📂 frontend/                   # Клиентская часть (React)
│   ├── App.jsx                   # Главный компонент (1420 строк)
│   ├── index.html               # HTML шаблон
│   ├── package.json             # NPM зависимости
│   ├── Dockerfile               # Docker образ для фронтенда
│   └── logo.png                 # Логотип
│
├── 📂 .github/                    # GitHub Actions
│   └── workflows/
│       └── deploy.yml           # Автодеплой (сохранён)
│
├── 📄 .env.example               # Пример конфигурации
├── 📄 .gitignore                # Git исключения
├── 📄 docker-compose.yml        # Оркестрация контейнеров
├── 📄 README.md                 # Основная документация
└── 📄 STRUCTURE.md              # Этот файл
```

---

## 📋 Описание ключевых файлов

### Backend

#### `main.py` (750 строк)
Основной файл бэкенда с:
- **Модели данных** (Pydantic): BranchRegister, MorningEvent, FieldVisit, и др.
- **Утилиты**: 
  - `get_sheets_client()` - авторизация в Google Sheets
  - `create_branch_spreadsheet()` - создание таблицы для филиала ⭐ НОВОЕ
  - `get_branch_spreadsheet_id()` - получение ID таблицы филиала ⭐ НОВОЕ
  - `ensure_sheet_exists()` - создание листов в таблице
  - `count_records_for_month()` - подсчёт записей
- **18 API endpoints**:
  - `/register` - регистрация филиала
  - `/login` - вход
  - `/morning-events/{branch_name}` - утренние мероприятия
  - `/field-visits/{branch_name}` - полевые выходы ⭐ ИСПРАВЛЕН БАГ ОЦЕНКИ
  - `/one-on-one/{branch_name}` - встречи 1-на-1
  - `/weekly-metrics/{branch_name}` - еженедельные показатели
  - `/newbie-adaptation/{branch_name}` - адаптация новичков
  - `/master-plans/{branch_name}` - планы мастеров
  - `/reviews/{branch_name}` - отзывы
  - `/branch-summary/{branch_name}` - сводка
  - `/dashboard-summary/{branch_name}` - дашборд

**Ключевые изменения v4.0**:
- Строка ~169: `create_branch_spreadsheet()` - автосоздание таблиц
- Строка ~183: `get_branch_spreadsheet_id()` - динамический выбор таблицы
- Строка ~560: Исправлен расчёт `overall_score` (деление на 5)

#### `requirements.txt`
Python зависимости:
```
fastapi==0.104.1
uvicorn[standard]==0.24.0
gspread==5.12.0
google-auth==2.23.4
pydantic==2.5.0
```

#### `Dockerfile`
Docker образ на базе `python:3.11-slim`

---

### Frontend

#### `App.jsx` (1420 строк)
Монолитный React компонент со всей логикой:

**Секции**:
1. **CONFIG** (строки 1-16): API_BASE_URL, BRANCH_GOALS
2. **API** (строки 17-41): Функция `api.request()`
3. **UTILS** (строки 42-58): `getWeekNumber()`, `getCurrentMonth()`
4. **ICONS** (строки 59-125): SVG иконки
5. **COMPONENTS** (строки 126-216):
   - `StarRating` - рейтинг звёздами
   - `FormInput` - поле формы
   - `Toast` - уведомление
   - `InstructionBanner` - инструкция
6. **AUTH** (строки 217-355): Страница входа/регистрации
7. **MAIN APP** (строки 356-483): Главное приложение с навигацией
8. **DASHBOARD** (строки 484-600): Дашборд с метриками
9. **FORMS** (строки 601-1420): 
   - MorningEventsPage - утренние мероприятия
   - FieldVisitsPage - полевые выходы ⭐ ИСПРАВЛЕН БАГ (строка 842)
   - OneOnOnePage - 1-on-1 встречи
   - WeeklyMetricsPage - еженедельные показатели
   - NewbieAdaptationPage - адаптация новичков
   - MasterPlansPage - планы мастеров
   - ReviewsPage - отзывы
   - BranchSummaryPage - сводка

**Ключевые изменения v4.0**:
- Строка 842: `calculateAverage()` - правильный расчёт среднего

#### `index.html`
HTML шаблон с подключением:
- React 18
- ReactDOM 18
- Tailwind CSS (CDN)

#### `package.json`
```json
{
  "scripts": {
    "dev": "vite",
    "build": "vite build"
  }
}
```

---

### Конфигурация

#### `.env.example`
```env
# ВАЖНО: В v4.0 это ID главной таблицы!
GOOGLE_SHEET_ID=your_master_spreadsheet_id_here

# JSON ключ сервисного аккаунта
GOOGLE_SERVICE_ACCOUNT_JSON={"type": "service_account", ...}
```

#### `docker-compose.yml`
Определяет 2 сервиса:
- **backend**: FastAPI на порту 8000
- **frontend**: Nginx на порту 80

Сеть: `barber_network`

Health check для backend: `http://localhost:8000/health`

---

## 🔄 Поток данных

```
Пользователь → Frontend (React) → Backend (FastAPI) → Google Sheets API
                                          ↓
                                  Главная таблица
                                  (список филиалов)
                                          ↓
                                  Таблица филиала
                                  (данные конкретного филиала)
```

---

## 📊 Размеры файлов

| Файл | Размер | Строк |
|------|--------|-------|
| backend/main.py | ~31 KB | 750 |
| frontend/App.jsx | ~95 KB | 1420 |
| Docker образ (backend) | ~450 MB | - |
| Docker образ (frontend) | ~25 MB | - |
| **Итого архив** | ~200 KB | - |

---

## 🔧 Технологический стек

### Backend
- **Язык**: Python 3.11
- **Фреймворк**: FastAPI 0.104
- **Сервер**: Uvicorn
- **Google API**: gspread 5.12
- **Валидация**: Pydantic 2.5

### Frontend
- **Библиотека**: React 18
- **Сборщик**: Vite (в dev режиме)
- **Стили**: Tailwind CSS 3
- **Иконки**: Heroicons (SVG)

### DevOps
- **Контейнеризация**: Docker
- **Оркестрация**: Docker Compose
- **CI/CD**: GitHub Actions
- **Веб-сервер**: Nginx (для фронтенда)

---

## 🎯 Точки входа

### Разработка

**Backend**:
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

**Frontend**:
```bash
cd frontend
npm install
npm run dev
```

### Продакшн

```bash
docker-compose up -d --build
```

---

## 📝 Примечания

### Автодеплой (.github/workflows/deploy.yml)
- Сохранён без изменений
- Триггер: push в main
- Действия: сборка и деплой контейнеров

### Логирование
Backend логирует в stdout/stderr:
- INFO: Успешные операции
- ERROR: Ошибки и исключения

Просмотр логов:
```bash
docker-compose logs -f backend
```

---

**Версия**: 4.0.0
**Дата**: Февраль 2026
