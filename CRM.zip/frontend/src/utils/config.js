export const API_BASE_URL = 'http://166.1.201.124:8000';

export const BRANCH_GOALS = {
  morning_events: 16,
  field_visits: 4,
  one_on_one: 6,
  weekly_reports: 4,
  master_plans: 10,
  reviews: 60,
  new_employees: 10
};
